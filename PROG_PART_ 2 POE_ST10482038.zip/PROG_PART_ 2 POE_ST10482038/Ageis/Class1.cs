
namespace Ageis
{
    public class Class1
    {
    }

}
