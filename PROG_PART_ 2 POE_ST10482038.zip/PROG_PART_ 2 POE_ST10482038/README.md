# AEGIS — Cyber Sentinel (Chatbot GUI)

AEGIS is a WPF chatbot that teaches cybersecurity best practices. It includes keyword recognition, randomized replies, sentiment-aware responses, short-term memory, and a polished dark GUI with TTS.

Quick start
- Requirements: Windows, Visual Studio Community 2022/2025/2026, .NET 10 SDK
- Open the Ageis solution in Visual Studio and build (no external NuGet packages required).
- Run the app (F5). On first run you'll be prompted for your name.

Core features
- Keyword recognition: Detects security keywords and returns a targeted reply (random variant).
- Random responses: Each keyword has several variants for more natural conversation.
- Sentiment detection: Detects simple tones (worried/curious/frustrated/happy) and prepends empathetic openers.
- Memory & personalization: Remembers your name and favourite topic for the session and personalizes replies.
- Conversation flow & follow-ups: Handles "tell me more" and similar follow-ups without resetting context.
- TTS greeting: Uses Windows SAPI.SpVoice for spoken greeting and replies (falls back silently if not available).
- Session persistence: Saves name and sound preference to %AppData%\AEGIS\session.json.
- UI: Topic sidebar (1–25), chat area, quick-tip/right panel with topic details and action buttons.

How to use
- Enter your name in the overlay prompt and press Enter or click "Let's Go".
- Type a topic number (1–25) to view details in the right panel.
- Type keywords like "password", "phishing", "privacy", "malware", "vpn", "2fa" to get targeted help.
- Type "menu" to flash the sidebar and list all topics. Type "exit" to quit.

Files of interest
- Ageis/Chatbot.cs — central routing logic that composes KeywordResponder, SentimentDetector, MemoryStore.
- Ageis/KeywordResponder.cs — keyword -> multiple responses mapping.
- Ageis/SentimentDetector.cs — basic sentiment detection and empathetic openers.
- Ageis/MemoryStore.cs — in-memory personal memory for name and favourite topic.
- Ageis/AudioPlayer.cs — TTS implementation (SAPI) and friendly speech wrapper.
- Ageis/SessionStore.cs — JSON persistence for name and sound setting.
- Ageis/MainWindow.xaml(.cs) — WPF UI and event handling.

Extending keywords and responses
- Edit Ageis/KeywordResponder.cs and add or extend response lists for new keywords.

Presentation & repository requirements (for submission)
- Make at least 6 descriptive commits demonstrating progress.
- Create at least 3 tagged releases (v1.0, v1.1, v1.2) and add release notes in CHANGELOG.md.
- Add your GitHub repository link and the YouTube unlisted demo (8–10 minutes) in this README before submission.

Example conversations
- User: (app starts and speaks) "Hello! I'm AEGIS. What's your name?"
- User: "Sam"
- Bot: "Nice to meet you, Sam! Ask me about cybersecurity topics like 'password' or 'phishing'."
- User: "password"
- Bot: "That's great to hear! Use a strong unique password and consider a reputable password manager."
- User: "tell me more"
- Bot: "More on Passwords & Authentication: Here are a few additional tips..."

Notes & limitations
- Sentiment detection is simple and rule-based — useful for demos but not production-grade.
- Audio uses system SAPI; if not available the app continues without audio.
- Memory is session-scoped and lightly persisted for name/sound only.

License
- MIT (add LICENSE file if you want to publish under MIT)

Presentation (placeholders)
- GitHub repo: <ADD_YOUR_GITHUB_LINK_HERE>
- YouTube demo: <ADD_YOUR_YOUTUBE_LINK_HERE>
