# CHANGELOG

All notable changes to this project will be documented in this file.

## [v1.2] - 2026-05-23
### Added
- Expanded chatbot keyword coverage and richer randomized responses.
- Implemented session persistence to remember the user's name and preferences across runs.
- Improved TTS support using Windows SAPI for spoken greetings and replies.

### Changed
- UI tweaks and improved quick-tip rotation.

## [v1.1] - 2026-05-20
### Added
- Initial WPF GUI with topics sidebar, typing indicator, and chat bubbles.
- Basic conversation memory and follow-up triggers.

## [v1.0] - 2026-05-18
### Added
- Core chatbot engine with keyword recognition, sentiment detection, and randomized responses.
- Modular code structure: Chatbot, User, ConversationContext, AudioPlayer.

