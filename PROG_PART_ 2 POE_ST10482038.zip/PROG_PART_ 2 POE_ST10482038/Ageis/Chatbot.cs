﻿using System;

namespace Ageis
{
    // Refactored Chatbot that composes KeywordResponder, SentimentDetector and MemoryStore
    // to provide the features required by Part 2 (keywords, random replies, sentiment,
    // follow-ups, and memory). Maintains a simple awaiting-name flow for first-run.
    internal class Chatbot
    {
        private readonly KeywordResponder _keywords = new();
        private readonly SentimentDetector _sentiment = new();
        private readonly MemoryStore _memory = new();

        private bool _awaitingName = true;
        private string _lastTopic = string.Empty;

        // Keep the same topic list used by the UI sidebar
        public string[] GetTopics()
        {
            return new[]
            {
                "Passwords & Authentication",
                "Phishing & Email Safety",
                "Secure Browsing",
                "Software Updates",
                "Wireless & Public Wi-Fi",
                "Social Engineering",
                "Data Backup",
                "Cloud Security",
                "Malware & Ransomware",
                "Secure Configuration",
                "Mobile Device Security",
                "Two-Factor Authentication",
                "Password Managers",
                "Physical Security",
                "Safe File Sharing",
                "Insider Threats",
                "Privacy Best Practices",
                "USB & Removable Media",
                "Secure Coding Basics",
                "Email Attachments",
                "Third-Party Risk",
                "Incident Reporting",
                "Identity Theft Prevention",
                "Browser Extensions",
                "IoT Device Security"
            };
        }

        // Returns a short greeting used by the UI when starting a session
        public string GetGreeting()
        {
            return "Hello! I'm Aegis, your Cybersecurity Assistant. What's your name?";
        }

        // Return a short detailed paragraph for each topic index (1-based)
        public string GetTopicDetails(int topicNumber)
        {
            var details = new[]
            {
                "Use unique, long passwords and consider a password manager. Enable MFA where possible.",
                "Be vigilant for phishing: verify sender, hover links, and never provide credentials via email.",
                "Use up-to-date browsers with security features enabled; avoid suspicious sites.",
                "Install updates promptly to fix vulnerabilities and protect against exploits.",
                "On public Wi‑Fi prefer a VPN and avoid sensitive transactions on untrusted networks.",
                "Social engineering preys on trust; verify identity and be cautious of unsolicited requests.",
                "Follow the 3-2-1 backup rule: keep multiple copies and test restores regularly.",
                "Protect cloud accounts with strong credentials, least privilege, and monitoring.",
                "Recognize ransomware signs, keep backups isolated, and update defenses.",
                "Harden default settings, close unused ports, and apply secure baselines.",
                "Use device encryption, screen locks, and update mobile OS/apps regularly.",
                "Use 2FA for critical accounts and prefer app-based authenticators or hardware keys.",
                "Password managers help create and store unique credentials securely.",
                "Physical security includes locking devices and protecting access to infrastructure.",
                "Share files via trusted services, encrypt sensitive attachments, and use access controls.",
                "Watch for insider threats: enforce least privilege and monitor unusual access patterns.",
                "Limit data collection, review privacy settings, and be mindful of sharing personal data.",
                "Scan removable media before use and disable autorun features to reduce risk.",
                "Follow secure coding best practices: input validation, least privilege, and code reviews.",
                "Open attachments cautiously; prefer scanning and verifying the sender first.",
                "Assess third-party vendors, monitor their access, and include security clauses in contracts.",
                "Report incidents promptly, preserve evidence, and follow your organisation's response plan.",
                "Protect identity data, use monitoring services for suspicious account activity.",
                "Review browser extensions; only install trusted ones and check permissions.",
                "Isolate IoT devices on separate networks and change default credentials."
            };

            if (topicNumber < 1 || topicNumber > details.Length) return string.Empty;
            return details[topicNumber - 1];
        }

        // Keep the existing signature used by the WPF UI: GetResponse(input, user)
        public string GetResponse(string input, User user)
        {
            if (string.IsNullOrWhiteSpace(input)) return string.Empty;
            var trimmed = input.Trim();
            // Record input in user's memory
            try
            {
                user?.RememberMessage(trimmed);
            }
            catch
            {
                // Keep Chatbot robust if user object is null or memory fails
            }

            // Handle numeric topic selection (1..N)
            if (int.TryParse(trimmed, out var topicNum))
            {
                var topics = GetTopics();
                if (topicNum >= 1 && topicNum <= topics.Length)
                {
                    var topic = topics[topicNum - 1];
                    _lastTopic = topic;
                    try { user?.RememberMessage(trimmed); user.LastTopic = topic; } catch { }
                    return $"Topic {topicNum}: {topic}\nHere's a short overview and some practical tips.";
                }
            }

            // Awaiting name capture
            if (_awaitingName)
            {
                _awaitingName = false;
                _memory.UserName = trimmed;
                if (user != null) user.Name = trimmed;
                return $"Nice to meet you, {trimmed}! Ask me about cybersecurity topics like 'password', 'phishing' or 'privacy'.";
            }

            var lower = trimmed.ToLowerInvariant();

            // Follow-up handling (must not reset chat)
            if (!string.IsNullOrEmpty(_lastTopic) && (lower.Contains("tell me more") || lower.Contains("more") || lower.Contains("explain") || lower.Contains("details")))
            {
                return $"More on {_lastTopic}: Here are a few additional tips and resources to help you.";
            }

            // Sentiment detection
            var sentiment = _sentiment.Detect(trimmed);
            var sentimentPrefix = _sentiment.GetSentimentResponse(sentiment);

            // Keyword responder
            var keyResponse = _keywords.GetResponse(trimmed, out var matchedKey);
            if (!string.IsNullOrEmpty(keyResponse))
            {
                _lastTopic = matchedKey;

                // If the user explicitly states interest, store favourite topic
                if (lower.Contains("interested in") || lower.Contains("i am interested in") || lower.Contains("i'm interested in"))
                {
                    _memory.FavouriteTopic = matchedKey;
                    // persist favourite topic
                    try { SessionStore.UpdateFavouriteTopic(matchedKey); } catch { }
                    // Also persist to a simple text file mapping names to favourite topics
                    try { UserDataStore.AppendOrUpdateUserFavourite(_memory.UserName ?? (user?.Name), matchedKey); } catch { }
                }

                // Personalisation
                if (_memory.UserName != null && user != null && string.IsNullOrEmpty(user.Name)) user.Name = _memory.UserName;
                var personal = _memory.GetPersonalisedOpener();

                // Update user's conversation memory
                try
                {
                    user?.RememberMessage(trimmed);
                    if (user != null) user.LastTopic = matchedKey;
                }
                catch { }

                return sentimentPrefix + personal + keyResponse;
            }

            // Special phrases
            if (lower.Contains("how are you")) return "I'm AEGIS, ready to help — what would you like to know about cybersecurity?";
            if (lower.Contains("what can you do") || lower.Contains("what can you") || lower.Contains("purpose"))
                return "I can help with passwords, phishing, privacy, malware, and general cyber hygiene — try typing a keyword like 'password'.";

            // Remember favourite topic when user says "I am interested in X"
            if (lower.StartsWith("i am interested in") || lower.StartsWith("i'm interested in") || lower.StartsWith("interested in"))
            {
                var idx = lower.IndexOf("in");
                if (idx >= 0)
                {
                    var topic = trimmed.Substring(idx + 2).Trim();
                    if (!string.IsNullOrWhiteSpace(topic))
                    {
                        _memory.FavouriteTopic = topic;
                        // persist favourite topic
                        try { SessionStore.UpdateFavouriteTopic(topic); } catch { }
                        try { UserDataStore.AppendOrUpdateUserFavourite(_memory.UserName ?? (user?.Name), topic); } catch { }
                        return $"Got it — I'll remember you're interested in {topic}.";
                    }
                }
            }

            // Fallback responses
            var fallbacks = new[]
            {
                "I didn't quite get that. Try a keyword like 'password' or 'phishing'.",
                "Could you rephrase? You can type 'menu' to see topic keywords.",
                "I'm not sure — ask about 'malware', 'privacy', or type a topic number if you know it."
            };
            var rng = new Random();
            return fallbacks[rng.Next(fallbacks.Length)];
        }
    }
}
