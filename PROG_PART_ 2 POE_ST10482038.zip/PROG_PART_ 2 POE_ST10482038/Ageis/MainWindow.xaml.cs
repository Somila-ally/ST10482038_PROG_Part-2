﻿using Ageis;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace CyberSecurityAwarenessBot
{
    /// <summary>
    /// Part 2 WPF GUI front-end.
    /// All logic in Chatbot, AudioPlayer and User is called without modification.
    /// </summary>
    public partial class MainWindow : Window
    {
        // ── Part-1 objects (unchanged) ────────────────────────────────────
        private readonly Chatbot _bot = new Chatbot();
        private readonly User _user = new User();

        // ── Session state ─────────────────────────────────────────────────
        private bool _soundEnabled = true;
        private int _messageCount = 0;
        private readonly HashSet<int> _exploredTopics = new HashSet<int>();
        private readonly DateTime _sessionStart = DateTime.Now;

        // ── Quick-tip rotation ────────────────────────────────────────────
        private readonly DispatcherTimer _tipTimer = new DispatcherTimer();
        private int _tipIndex = 0;

        private static readonly string[] QuickTips = new[]
        {
            "Never reuse the same password across different websites.",
            "Enable two-factor authentication on all critical accounts.",
            "Always verify the sender before opening email attachments.",
            "Keep your software and operating system fully up to date.",
            "Use a reputable VPN on public Wi-Fi to protect your data."
        };

        // ── Typing-indicator dot animation ────────────────────────────────
        private readonly DispatcherTimer _dotTimer = new DispatcherTimer();
        private int _dotStep = 0;
        private static readonly string[] DotFrames = { "●  ○  ○", "●  ●  ○", "●  ●  ●", "○  ●  ●", "○  ○  ●" };

        // ── Sidebar topic item (used for data binding) ─────────────────────
        private class TopicItem
        {
            public string DisplayText { get; set; } = string.Empty;
            public int Number { get; set; }
        }

        // ══════════════════════════════════════════════════════════════════
        // CONSTRUCTOR & LOADED
        // ══════════════════════════════════════════════════════════════════
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Session stats
            SessionStartLabel.Text = _sessionStart.ToString("HH:mm");

            // Populate sidebar topics from Part-1 Chatbot (unchanged)
            var topics = _bot.GetTopics();
            var items = new List<TopicItem>();
            for (int i = 0; i < topics.Length; i++)
                items.Add(new TopicItem { Number = i + 1, DisplayText = $"{i + 1}.  {topics[i]}" });
            TopicsListControl.ItemsSource = items;

            // Quick tips
            QuickTipLabel.Text = QuickTips[0];
            TipCounterLabel.Text = $"Tip 1 of {QuickTips.Length}  •  refreshes every 30 s";
            _tipTimer.Interval = TimeSpan.FromSeconds(30);
            _tipTimer.Tick += TipTimer_Tick;
            _tipTimer.Start();

            // Typing dots animation
            _dotTimer.Interval = TimeSpan.FromMilliseconds(300);
            _dotTimer.Tick += (s, _) =>
            {
                _dotStep = (_dotStep + 1) % DotFrames.Length;
                TypingDotsLabel.Text = DotFrames[_dotStep];
            };

            // Ensure the name overlay is visible and focus the name input box
            try
            {
                NameOverlay.Visibility = Visibility.Visible;
                Dispatcher.BeginInvoke(new Action(() => NameInputBox.Focus()), DispatcherPriority.Input);
            }
            catch { }

            // Show greeting text in chat area (overlay remains on top) so user sees the prompt
            try
            {
                AddBotMessage(_bot.GetGreeting());
            }
            catch { }

            // Load saved session if available
            SessionStore.SessionData? session = null;
            try
            {
                session = SessionStore.Load();
                if (session != null)
                {
                    _soundEnabled = session.SoundEnabled;
                    SoundToggleBtn.Content = _soundEnabled ? "Sound ON" : "Sound OFF";
                    SoundToggleBtn.Foreground = _soundEnabled
                        ? new SolidColorBrush(Color.FromRgb(0, 255, 156))
                        : new SolidColorBrush(Color.FromRgb(139, 143, 168));

                    if (!string.IsNullOrWhiteSpace(session.Name))
                    {
                        // Prefill name but do not auto-confirm; keep overlay visible so user can
                        // change or confirm their name explicitly.
                        NameInputBox.Text = session.Name;
                    }

                    if (!string.IsNullOrWhiteSpace(session.FavouriteTopic))
                    {
                        _user.Preferences["favourite_topic"] = session.FavouriteTopic;
                        // also preload right panel with favourite topic if it matches a known topic
                        for (int i = 0; i < topics.Length; i++)
                        {
                            if (topics[i].ToLowerInvariant().Contains(session.FavouriteTopic.ToLowerInvariant()))
                            {
                                var details = _bot.GetTopicDetails(i + 1);
                                TopicTitleLabel.Text = $"{i+1}. {topics[i]}";
                                QuickTipLabel.Text = details;
                                TipCounterLabel.Text = $"Favourite topic";
                                break;
                            }
                        }
                    }
                }
            }
            catch { }

            // If a name was loaded from session, also load recent chat history into the UI
            try
            {
                var nameToLoad = session?.Name;
                if (!string.IsNullOrWhiteSpace(nameToLoad))
                {
                    var history = ChatDataStore.ReadChatHistory(nameToLoad);
                    foreach (var entry in history)
                    {
                        var whoIsBot = !entry.isUser;
                        ChatPanel.Children.Add(BuildBubble(entry.message, isBot: whoIsBot));
                    }
                }
            }
            catch { }

            // Optionally show the stored user->favourite mappings in the quick tip area
            try
            {
                var all = UserDataStore.ReadAll();
                if (all.Count > 0)
                {
                    // append a short summary to QuickTipLabel (non-intrusive)
                    QuickTipLabel.Text += "\n\nSaved users:";
                    int shown = 0;
                    foreach (var kv in all)
                    {
                        if (shown >= 5) { QuickTipLabel.Text += "\n..."; break; }
                        QuickTipLabel.Text += $"\n{kv.Key}: {kv.Value}";
                        shown++;
                    }
                }
            }
            catch { }

            // After loading session, also show the general welcome and usage instructions
            try
            {
                AddBotMessage($"Welcome to AEGIS Cyber Sentinel! 🛡️");
                AddBotMessage(
                    "I'm Aegis, your Cyber Sentinel. You can:\n" +
                    "  • Type a topic number  1–25\n" +
                    "  • Ask a cybersecurity question\n" +
                    "  • Type 'menu' to see all topics\n" +
                    "  • Type 'exit' to quit");
            }
            catch { }

            // Audio greeting: speak the chatbot's greeting (asks for the user's name)
            Task.Run(() =>
            {
                try { AudioPlayer.EnsureGreetingAudioExists(); } catch { /* non-fatal */ }
                try { AudioPlayer.SpeakText(_bot.GetGreeting()); } catch { /* non-fatal */ }
            });
        }

        // ══════════════════════════════════════════════════════════════════
        // QUICK-TIP ROTATION
        // ══════════════════════════════════════════════════════════════════
        private void TipTimer_Tick(object? sender, EventArgs e)
        {
            _tipIndex = (_tipIndex + 1) % QuickTips.Length;
            var fade = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(500));
            QuickTipLabel.Opacity = 0;
            QuickTipLabel.Text = QuickTips[_tipIndex];
            TipCounterLabel.Text = $"Tip {_tipIndex + 1} of {QuickTips.Length}  •  refreshes every 30 s";
            QuickTipLabel.BeginAnimation(OpacityProperty, fade);
        }

        // ══════════════════════════════════════════════════════════════════
        // NAME OVERLAY
        // ══════════════════════════════════════════════════════════════════
        private void NameInputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) ConfirmNameEntry();
        }

        private void ConfirmName_Click(object sender, RoutedEventArgs e) => ConfirmNameEntry();

        private void ConfirmNameEntry()
        {
            var name = NameInputBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(name))
            {
                NameErrorLabel.Text = "Please enter your name to continue.";
                NameErrorLabel.Visibility = Visibility.Visible;
                NameInputBox.Focus();
                return;
            }

            _user.Name = name;

            // Save session with name and audio preference
            try
            {
                SessionStore.Save(new SessionStore.SessionData { Name = name, SoundEnabled = _soundEnabled });
            }
            catch { }

            // Fade out overlay
            var fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(350));
            fadeOut.Completed += (s, _) =>
            {
                NameOverlay.Visibility = Visibility.Collapsed;
                InputBox.Focus();

                // Post initial bot messages
                AddBotMessage($"Welcome to AEGIS Cyber Sentinel, {_user.Name}! 🛡️");
                AddBotMessage(
                    "I'm Aegis, your Cyber Sentinel. You can:\n" +
                    "  • Type a topic number  1–25\n" +
                    "  • Ask a cybersecurity question\n" +
                    "  • Type 'menu' to see all topics\n" +
                    "  • Type 'exit' to quit");

                // Speak a short ASCII-style friendly banner (kept brief for TTS)
                try
                {
                    var banner = "Welcome to AEGIS Cyber Sentinel. I am your Cybersecurity Assistant.";
                    Task.Run(() => { try { AudioPlayer.SpeakText(banner); } catch { } });
                }
                catch { }

                // Speak personalised greeting (Part-1 AudioPlayer — unchanged)
                if (_soundEnabled)
                {
                    Task.Run(() =>
                    {
                        try
                        {
                            AudioPlayer.SpeakText(
                                $"Hello {_user.Name}. Welcome to the Cybersecurity Awareness Bot.");
                        }
                        catch { /* non-fatal */ }
                    });
                }
            };
            NameOverlay.BeginAnimation(OpacityProperty, fadeOut);
        }

        private void ViewHistoryBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dlg = new ChatHistoryWindow(_user.Name);
                dlg.Owner = this;
                dlg.ShowDialog();
            }
            catch { }
        }

        // ══════════════════════════════════════════════════════════════════
        // INPUT — SEND LOGIC
        // ══════════════════════════════════════════════════════════════════
        private async void SendButton_Click(object sender, RoutedEventArgs e) => await SendInputAsync();
        private async void InputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) await SendInputAsync();
        }

        private async Task SendInputAsync()
        {
            // Overlay still visible — don't process chat yet
            if (NameOverlay.Visibility == Visibility.Visible) return;

            var input = InputBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(input)) return;

            InputBox.Clear();
            AddUserMessage(input);

            // ── exit ──
            if (input.Equals("exit", StringComparison.OrdinalIgnoreCase))
            {
                AddBotMessage("Goodbye! Stay safe online. 🛡️");
                await Task.Delay(1300);
                Application.Current.Shutdown();
                return;
            }

            // ── menu ──
            if (input.Equals("menu", StringComparison.OrdinalIgnoreCase))
            {
                FlashSidebar();
                AddBotMessage("Here are all 25 topics — click any button in the sidebar, or type its number!");
                return;
            }

            // ── track explored topics ──
            if (int.TryParse(input, out var n) && n >= 1 && n <= 25)
            {
                _exploredTopics.Add(n);
                TopicsExploredLabel.Text = _exploredTopics.Count.ToString();
            }

            // If numeric topic selected, show details in QuickTipLabel and right panel
            if (int.TryParse(input, out var topicIndex) && topicIndex >= 1 && topicIndex <= 25)
            {
                try
                {
                    var details = _bot.GetTopicDetails(topicIndex);
                    var title = _bot.GetTopics()[topicIndex - 1];
                    TopicTitleLabel.Text = $"{topicIndex}. {title}";
                    QuickTipLabel.Text = details;
                    TipCounterLabel.Text = $"Topic {topicIndex} details";

                    // Show action buttons
                    ReadMoreBtn.Visibility = Visibility.Visible;
                    SearchOnlineBtn.Visibility = Visibility.Visible;
                }
                catch { }
            }

            // ── typing indicator ──
            SetTyping(true);

            // Call Part-1 Chatbot.GetResponse on background thread (unchanged signature)
            var response = await Task.Run(() => _bot.GetResponse(input, _user));

            SetTyping(false);
            AddBotMessage(response);

            // Save session after exchanges (persist name and audio setting)
            try
            {
                    // preserve recent messages up to last 20 for session persistence
                    var recentList = new List<string>();
                    for (int i = Math.Max(0, ChatPanel.Children.Count - 20); i < ChatPanel.Children.Count; i++)
                    {
                        var child = ChatPanel.Children[i];
                        if (child is Grid g && g.Tag is string t)
                        {
                            recentList.Add(t);
                        }
                    }

                    SessionStore.UpdateRecentMessages(recentList.ToArray());
                    SessionStore.Save(new SessionStore.SessionData { Name = _user.Name, SoundEnabled = _soundEnabled });
            }
            catch { }

            // Speak response (Part-1 AudioPlayer — unchanged)
            if (_soundEnabled)
            {
                Task.Run(() =>
                {
                    try { AudioPlayer.SpeakText(response); }
                    catch { /* non-fatal */ }
                });
            }
        }

        // ── Topic sidebar button click ─────────────────────────────────────
        private void TopicButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is int num)
            {
                InputBox.Text = num.ToString();
                _ = SendInputAsync();
            }
        }

        private void ReadMoreBtn_Click(object sender, RoutedEventArgs e)
        {
            // For now, simply open a web search for the displayed topic title
            try
            {
                var title = TopicTitleLabel.Text;
                if (string.IsNullOrWhiteSpace(title)) return;

                // Try to open a curated resource for the selected topic, fallback to a web search
                var url = GetTopicUrlFromTitle(title);
                if (string.IsNullOrEmpty(url))
                {
                    var query = Uri.EscapeDataString(title);
                    url = $"https://www.bing.com/search?q={query}";
                }

                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = url,
                    UseShellExecute = true
                });
            }
            catch { }
        }

        private void SearchOnlineBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var title = TopicTitleLabel.Text;
                if (string.IsNullOrWhiteSpace(title)) return;
                var query = Uri.EscapeDataString(title);
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = $"https://www.bing.com/search?q={query}",
                    UseShellExecute = true
                });
            }
            catch { }
        }

        private string GetTopicUrlFromTitle(string title)
        {
            // title may contain a leading "N. ", strip it
            var parts = title.Split(new[] {'.'}, 2);
            var trimmed = parts.Length > 1 ? parts[1].Trim() : title.Trim();

            // Map common topic titles to curated resources (index-based alternative)
            // Use lower-case to match
            var t = trimmed.ToLowerInvariant();

            if (t.Contains("password")) return "https://www.cisa.gov/uscert/ncas/tips/ST04-002";
            if (t.Contains("phishing")) return "https://www.consumer.ftc.gov/articles/how-recognize-and-avoid-phishing-scams";
            if (t.Contains("secure browsing")) return "https://www.microsoft.com/security/blog/";
            if (t.Contains("software updates")) return "https://us-cert.cisa.gov/ncas/tips/ST04-006";
            if (t.Contains("wi") && t.Contains("wi")) return "https://www.ncsc.gov.uk/guidance/using-public-wifi-safely";
            if (t.Contains("backup")) return "https://www.ncsc.gov.uk/guidance/backing-up-your-data";
            if (t.Contains("malware")) return "https://www.microsoft.com/security/blog/2020/09/09/what-is-malware/";
            if (t.Contains("two-factor") || t.Contains("2fa")) return "https://www.cisa.gov/uscert/resources/home-network-security";
            if (t.Contains("password managers")) return "https://www.consumer.ftc.gov/articles/password-managers";
            if (t.Contains("privacy")) return "https://www.privacyrights.org/";
            if (t.Contains("iot")) return "https://www.nist.gov/programs-projects/internet-things-iot";

            // Default: no curated URL
            return string.Empty;
        }

        // ══════════════════════════════════════════════════════════════════
        // CHAT BUBBLE RENDERING
        // ══════════════════════════════════════════════════════════════════
        private void AddBotMessage(string text)
        {
            _messageCount++;
            MessageCountLabel.Text = _messageCount.ToString();
            ChatPanel.Children.Add(BuildBubble(text, isBot: true));
            // Persist bot message to chat history for the current user
            try
            {
                ChatDataStore.AppendChat(_user.Name, false, text);
            }
            catch { }
            ScrollToBottom();
            // Speak bot message immediately so user hears it even while the name overlay is shown
            try
            {
                if (_soundEnabled)
                {
                    var speakText = text;
                    // keep spoken text concise: prefer a single-line summary if long
                    if (speakText.Length > 240)
                    {
                        speakText = speakText.Substring(0, 240) + "...";
                    }
                    Task.Run(() => { try { AudioPlayer.SpeakText(speakText); } catch { } });
                }
            }
            catch { }
        }

        private void AddUserMessage(string text)
        {
            _messageCount++;
            MessageCountLabel.Text = _messageCount.ToString();
            ChatPanel.Children.Add(BuildBubble(text, isBot: false));
            ScrollToBottom();
        }

        private UIElement BuildBubble(string text, bool isBot)
        {
            // ── Outer wrapper (controls left/right alignment) ──────────────
            var wrapper = new Grid { Margin = new Thickness(0, 5, 0, 5) };
            // store the raw text on the wrapper for easy persistence later
            wrapper.Tag = text;

            // ── Row: avatar + bubble stack ─────────────────────────────────
            var row = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = isBot ? HorizontalAlignment.Left : HorizontalAlignment.Right,
                MaxWidth = 540
            };

            // Bot avatar
            if (isBot)
            {
                var avatar = new Border
                {
                    Width = 34,
                    Height = 34,
                    Background = new SolidColorBrush(Color.FromRgb(0, 255, 156)),
                    CornerRadius = new CornerRadius(10),
                    Margin = new Thickness(0, 0, 10, 0),
                    VerticalAlignment = VerticalAlignment.Top
                };
                avatar.Child = new TextBlock
                {
                    Text = "⬡",
                    FontSize = 15,
                    Foreground = new SolidColorBrush(Color.FromRgb(13, 15, 20)),
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                };
                row.Children.Add(avatar);
            }

            // ── Bubble column ──────────────────────────────────────────────
            var col = new StackPanel();

            // Sender name
            col.Children.Add(new TextBlock
            {
                Text = isBot ? "AEGIS" : (_user.Name ?? "You"),
                FontSize = 10,
                FontWeight = FontWeights.SemiBold,
                Foreground = isBot
                    ? new SolidColorBrush(Color.FromRgb(0, 255, 156))
                    : new SolidColorBrush(Color.FromRgb(139, 143, 168)),
                Margin = new Thickness(0, 0, 0, 4)
            });

            // Message bubble
            var bubble = new Border
            {
                Background = isBot
                    ? new SolidColorBrush(Color.FromRgb(26, 29, 39))
                    : new SolidColorBrush(Color.FromRgb(34, 38, 56)),
                CornerRadius = isBot
                    ? new CornerRadius(4, 14, 14, 14)
                    : new CornerRadius(14, 4, 14, 14),
                Padding = new Thickness(16, 11, 16, 11),
                BorderThickness = isBot ? new Thickness(2, 0, 0, 0) : new Thickness(0),
                BorderBrush = isBot
                    ? new SolidColorBrush(Color.FromRgb(0, 255, 156))
                    : null
            };
            bubble.Child = new TextBlock
            {
                Text = text,
                FontFamily = new FontFamily("Segoe UI"),
                FontSize = 14,
                Foreground = new SolidColorBrush(Color.FromRgb(232, 233, 240)),
                TextWrapping = TextWrapping.Wrap,
                LineHeight = 21
            };
            col.Children.Add(bubble);

            // Timestamp
            col.Children.Add(new TextBlock
            {
                Text = DateTime.Now.ToString("HH:mm"),
                FontSize = 10,
                Foreground = new SolidColorBrush(Color.FromRgb(139, 143, 168)),
                HorizontalAlignment = isBot ? HorizontalAlignment.Left : HorizontalAlignment.Right,
                Margin = new Thickness(0, 4, 0, 0)
            });

            row.Children.Add(col);
            wrapper.Children.Add(row);

            // Fade-in slide animation
            wrapper.Opacity = 0;
            wrapper.RenderTransform = new TranslateTransform(0, isBot ? 8 : -8);
            var fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(280));
            var slideIn = new DoubleAnimation(isBot ? 8 : -8, 0, TimeSpan.FromMilliseconds(280));
            wrapper.BeginAnimation(OpacityProperty, fadeIn);
            wrapper.RenderTransform.BeginAnimation(TranslateTransform.YProperty, slideIn);

            return wrapper;
        }

        // ══════════════════════════════════════════════════════════════════
        // HELPERS
        // ══════════════════════════════════════════════════════════════════
        private void ScrollToBottom()
        {
            Dispatcher.BeginInvoke(DispatcherPriority.Loaded,
                new Action(() => ChatScrollViewer.ScrollToBottom()));
        }

        private void SetTyping(bool show)
        {
            TypingIndicator.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
            if (show) { _dotTimer.Start(); ScrollToBottom(); }
            else _dotTimer.Stop();
        }

        private async void FlashSidebar()
        {
            // Briefly pulse the sidebar accent border to draw attention
            for (int i = 0; i < 3; i++)
            {
                SidebarBorder.BorderBrush = new SolidColorBrush(Color.FromRgb(0, 255, 156));
                SidebarBorder.BorderThickness = new Thickness(0, 0, 2, 0);
                await Task.Delay(200);
                SidebarBorder.BorderBrush = new SolidColorBrush(Color.FromRgb(42, 45, 62));
                SidebarBorder.BorderThickness = new Thickness(0, 0, 1, 0);
                await Task.Delay(200);
            }
        }

        private void SoundToggle_Click(object sender, RoutedEventArgs e)
        {
            _soundEnabled = !_soundEnabled;
            SoundToggleBtn.Content = _soundEnabled ? "Sound ON" : "Sound OFF";
            SoundToggleBtn.Foreground = _soundEnabled
                ? new SolidColorBrush(Color.FromRgb(0, 255, 156))
                : new SolidColorBrush(Color.FromRgb(139, 143, 168));
        }

        private void InputBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            InputPlaceholder.Visibility =
                string.IsNullOrEmpty(InputBox.Text) ? Visibility.Visible : Visibility.Collapsed;
        }
    }
}
