// This project is WPF-only. Remove placeholder WinForms MainForm to avoid build errors.
// The original repository appears to contain leftover files for a different UI.

// Intentionally empty - kept as source file to avoid unexpected project changes.

