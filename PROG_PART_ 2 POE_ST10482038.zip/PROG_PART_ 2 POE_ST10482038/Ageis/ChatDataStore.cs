using System;
using System.Collections.Generic;
using System.IO;

namespace Ageis
{
    // Simple file-backed chat history store. Each user's chat is stored in a separate text file
    // with lines formatted as: ticks|IsUser|Message
    internal static class ChatDataStore
    {
        private static readonly string _dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "AEGIS", "chats");
        private static readonly object _lock = new();

        private static string SanitizeFileName(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return "anonymous";
            foreach (var c in Path.GetInvalidFileNameChars()) name = name.Replace(c, '_');
            return name.Trim();
        }

        public static void ClearChat(string? userName)
        {
            try
            {
                var fileName = SanitizeFileName(userName ?? "anonymous") + ".txt";
                var path = Path.Combine(_dir, fileName);
                if (File.Exists(path)) File.Delete(path);
            }
            catch
            {
                // ignore
            }
        }

        public static void ClearAllChats()
        {
            try
            {
                if (!Directory.Exists(_dir)) return;
                foreach (var file in Directory.GetFiles(_dir, "*.txt"))
                {
                    try { File.Delete(file); } catch { }
                }
            }
            catch
            {
                // ignore
            }
        }

        public static void AppendChat(string? userName, bool isUser, string message)
        {
            try
            {
                var fileName = SanitizeFileName(userName ?? "anonymous") + ".txt";
                Directory.CreateDirectory(_dir);
                var path = Path.Combine(_dir, fileName);
                lock (_lock)
                {
                    using var sw = new StreamWriter(path, true);
                    sw.WriteLine($"{DateTime.UtcNow.Ticks}|{(isUser ? "U" : "B")}|{message}");
                }
            }
            catch
            {
                // ignore write failures for simplicity
            }
        }

        public static List<(DateTime time, bool isUser, string message)> ReadChatHistory(string? userName)
        {
            var result = new List<(DateTime, bool, string)>();
            try
            {
                var fileName = SanitizeFileName(userName ?? "anonymous") + ".txt";
                var path = Path.Combine(_dir, fileName);
                if (!File.Exists(path)) return result;
                lock (_lock)
                {
                    foreach (var line in File.ReadAllLines(path))
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;
                        var parts = line.Split(new[] { '|' }, 3);
                        if (parts.Length < 3) continue;
                        if (!long.TryParse(parts[0], out var ticks)) continue;
                        var who = parts[1];
                        var msg = parts[2];
                        var time = new DateTime(ticks, DateTimeKind.Utc);
                        result.Add((time, who == "U", msg));
                    }
                }
            }
            catch
            {
                // ignore read errors
            }

            return result;
        }
    }
}
