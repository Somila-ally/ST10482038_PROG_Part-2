using System;
using System.Collections.Generic;

namespace Ageis
{
    // Maintains the conversational state for a single chatbot session.
    // One instance lives inside User and is updated after every exchange.
    internal class ConversationContext
    {
        public string? LastTopic { get; private set; }
        public string? LastQuestion { get; private set; }
        public int LastMenuSelection { get; private set; }
        public int ExchangeCount { get; private set; }

        private static readonly string[] _followUpTriggers = new[]
        {
            "tell me more",
            "more info",
            "more information",
            "explain",
            "elaborate",
            "go on",
            "continue",
            "what else",
            "more about that",
            "can you explain",
            "more detail",
            "details please",
            "expand",
            "give me more",
            "and then",
            "what about"
        };

        public bool HasContext => LastTopic != null;

        public bool IsFollowUp(string input)
        {
            if (!HasContext || string.IsNullOrWhiteSpace(input)) return false;

            var lower = input.ToLowerInvariant();
            foreach (var trigger in _followUpTriggers)
                if (lower.Contains(trigger)) return true;

            return false;
        }

        public void Update(string userInput, string? topicKeyword = null, int menuSelection = 0)
        {
            LastQuestion = userInput;
            ExchangeCount++;

            if (topicKeyword != null) LastTopic = topicKeyword;
            if (menuSelection > 0) LastMenuSelection = menuSelection;
        }

        public void Reset()
        {
            LastTopic = null;
            LastQuestion = null;
            LastMenuSelection = 0;
            // ExchangeCount intentionally preserved (session-level metric)
        }
    }
}
