using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Ageis
{
    public partial class ChatHistoryWindow : Window
    {
        private readonly string? _userName;

        // Runtime references to controls defined in XAML (resolved after InitializeComponent)
        private ListBox _historyList = null!;
        private TextBlock _headerLabel = null!;

        public ChatHistoryWindow(string? userName)
        {
            _userName = userName;
            InitializeComponent();
            _headerLabel = (TextBlock)FindName("HeaderLabel")!;
            _historyList = (ListBox)FindName("HistoryList")!;
            _headerLabel.Text = string.IsNullOrWhiteSpace(userName) ? "Chat history (anonymous)" : $"Chat history for {userName}";
            LoadHistory();
        }

        private class HistoryItem
        {
            public string Time { get; set; } = string.Empty;
            public string Who { get; set; } = string.Empty;
            public string Msg { get; set; } = string.Empty;
            public override string ToString() => $"[{Time}] {Who}: {Msg}";
        }

        private void LoadHistory()
        {
            try
            {
                var lines = ChatDataStore.ReadChatHistory(_userName);
                _historyList.ItemsSource = lines.Select(l => new HistoryItem
                {
                    Time = l.time.ToLocalTime().ToString("g"),
                    Who = l.isUser ? "You" : "AEGIS",
                    Msg = l.message
                }).ToList();
            }
            catch
            {
                _historyList.Items.Clear();
            }
        }

        private void ExportBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dlg = new Microsoft.Win32.SaveFileDialog { FileName = ($"chat_{(_userName ?? "anon").Replace(' ', '_')}.txt") };
                if (dlg.ShowDialog(this) == true)
                {
                    File.WriteAllLines(dlg.FileName, _historyList.Items.Cast<object>().Select(i => i.ToString()));
                }
            }
            catch
            {
                MessageBox.Show(this, "Failed to export chat history.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ClearBtn_Click(object sender, RoutedEventArgs e)
        {
            var r = MessageBox.Show(this, "Delete all saved chat messages for this user? This cannot be undone.", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (r != MessageBoxResult.Yes) return;
            try
            {
                ChatDataStore.ClearChat(_userName);
                LoadHistory();
            }
            catch
            {
                MessageBox.Show(this, "Failed to clear chat history.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e) => Close();

        private void ClearAllBtn_Click(object sender, RoutedEventArgs e)
        {
            var r = MessageBox.Show(this, "Delete all saved chat files for all users? This cannot be undone.", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (r != MessageBoxResult.Yes) return;
            try
            {
                ChatDataStore.ClearAllChats();
                LoadHistory();
            }
            catch
            {
                MessageBox.Show(this, "Failed to clear all chat histories.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

    }
}
