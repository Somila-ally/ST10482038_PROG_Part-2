using System.Collections.Generic;

namespace Ageis
{
    internal class MemoryStore
    {
        private readonly Dictionary<string, string> _store = new();

        public string? UserName
        {
            get => Recall("name");
            set { Store("name", value ?? string.Empty); }
        }

        public string? FavouriteTopic
        {
            get => Recall("favourite_topic");
            set { Store("favourite_topic", value ?? string.Empty); }
        }

        public void Store(string key, string value)
        {
            _store[key] = value;
        }

        public string? Recall(string key)
        {
            return _store.TryGetValue(key, out var v) ? v : null;
        }

        public string GetPersonalisedOpener()
        {
            var parts = new List<string>();
            if (!string.IsNullOrWhiteSpace(UserName)) parts.Add(UserName!);
            if (!string.IsNullOrWhiteSpace(FavouriteTopic)) parts.Add($"interested in {FavouriteTopic}");
            if (parts.Count == 0) return string.Empty;
            return "As " + string.Join(" and ", parts) + ", " ;
        }
    }
}
