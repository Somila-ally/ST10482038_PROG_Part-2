using System;
using System.IO;
using System.Text.Json;

namespace Ageis
{
    // Simple JSON-backed session store to persist minimal user data between runs.
    internal static class SessionStore
    {
        private static readonly string _dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "AEGIS");
        private static readonly string _file = Path.Combine(_dir, "session.json");

        internal class SessionData
        {
            public string? Name { get; set; }
            public string? FavouriteTopic { get; set; }
            public bool SoundEnabled { get; set; } = true;
            public string[]? RecentMessages { get; set; }
        }

        public static SessionData? Load()
        {
            try
            {
                if (!File.Exists(_file)) return null;
                var json = File.ReadAllText(_file);
                return JsonSerializer.Deserialize<SessionData>(json);
            }
            catch
            {
                return null;
            }
        }

        public static void Save(SessionData data)
        {
            try
            {
                Directory.CreateDirectory(_dir);
                var options = new JsonSerializerOptions { WriteIndented = true };
                var json = JsonSerializer.Serialize(data, options);
                File.WriteAllText(_file, json);
            }
            catch
            {
                // ignore persistence failures
            }
        }

        public static void UpdateFavouriteTopic(string? topic)
        {
            try
            {
                var existing = Load() ?? new SessionData();
                existing.FavouriteTopic = topic;
                Save(existing);
            }
            catch { }
        }

        public static void UpdateRecentMessages(string[] messages)
        {
            try
            {
                var existing = Load() ?? new SessionData();
                existing.RecentMessages = messages;
                Save(existing);
            }
            catch { }
        }
    }
}
