using System;
using System.Collections.Generic;

namespace Ageis
{
    // Minimal user model used by the UI and chatbot. Real project may define more fields.
    internal class User
    {
        private string? _name;
        public string? Name
        {
            get => _name;
            set
            {
                _name = value;
                // Persist favourite or ensure user's chat file exists when name set (no-op if null)
                if (!string.IsNullOrWhiteSpace(_name))
                {
                    // Ensure user data folder exists by writing an initial line (ignored by reader)
                    UserDataStore.AppendOrUpdateUserFavourite(_name, Conversation.LastTopic);
                }
            }
        }
        public string? Email { get; set; }

        // Conversation context for this user/session
        public ConversationContext Conversation { get; } = new ConversationContext();

        // Stores the last topic discussed with the chatbot. Keep in sync with Conversation.
        private string? _lastTopic;
        public string? LastTopic
        {
            get => _lastTopic;
            set
            {
                _lastTopic = value;
                if (value != null)
                {
                    // Update conversation context when topic is set from outside
                    Conversation.Update(string.Empty, value, 0);
                }
            }
        }

        // Stores the last question asked by the user. Keep in sync with Conversation.
        private string? _lastQuestion;
        public string? LastQuestion
        {
            get => _lastQuestion;
            set
            {
                _lastQuestion = value;
                if (!string.IsNullOrEmpty(value))
                {
                    Conversation.Update(value, null, 0);
                }
            }
        }

        // Stores user preferences as key-value pairs
        public Dictionary<string, string> Preferences { get; } = new();

        // Records a message in the user's memory and updates conversation context
        public void RememberMessage(string message)
        {
            // Update conversation context with the raw user input
            if (!string.IsNullOrEmpty(message))
            {
                Conversation.Update(message, null, 0);
                _lastQuestion = message;
                // Persist chat message
                ChatDataStore.AppendChat(Name, true, message);
            }
        }

        // Load chat transcript for this user
        public List<(DateTime time, bool isUser, string message)> LoadChatHistory()
        {
            return ChatDataStore.ReadChatHistory(Name);
        }
    }
}
