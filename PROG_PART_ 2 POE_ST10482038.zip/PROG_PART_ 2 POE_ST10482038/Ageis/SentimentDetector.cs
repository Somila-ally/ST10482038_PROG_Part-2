using System;
using System.Collections.Generic;
using System.Linq;

namespace Ageis
{
    internal enum Sentiment { Neutral, Worried, Curious, Frustrated, Happy }

    internal class SentimentDetector
    {
        private readonly Dictionary<Sentiment, List<string>> _triggers = new();

        public SentimentDetector()
        {
            _triggers[Sentiment.Worried] = new List<string> { "worried", "scared", "afraid", "anxious", "nervous", "unsafe", "concerned", "panic", "fear", "help", "oh no", "uh oh" };
            _triggers[Sentiment.Curious] = new List<string> { "curious", "wondering", "interested", "how", "what", "why", "explain", "tell me more", "can you explain", "details", "more info" };
            _triggers[Sentiment.Frustrated] = new List<string> { "frustrat", "annoy", "confus", "don't understand", "can't", "cannot", "stuck", "broken", "doesn't work", "fail", "error", "problem" };
            _triggers[Sentiment.Happy] = new List<string> { "great", "thanks", "helpful", "awesome", "love", "good", "nice", "excellent", "yay", "cool" };
        }

        public Sentiment Detect(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return Sentiment.Neutral;
            var lower = input.ToLowerInvariant();

            foreach (var kv in _triggers)
            {
                foreach (var token in kv.Value)
                {
                    if (lower.Contains(token)) return kv.Key;
                }
            }

            return Sentiment.Neutral;
        }

        public string GetSentimentResponse(Sentiment s)
        {
            return s switch
            {
                Sentiment.Worried => "I can see this is worrying — let's take it step by step. ",
                Sentiment.Curious => "That's a great question — here's some info: ",
                Sentiment.Frustrated => "I'm sorry this is frustrating — I will try to explain clearly. ",
                Sentiment.Happy => "I'm glad that helped! ",
                _ => string.Empty
            };
        }
    }
}
