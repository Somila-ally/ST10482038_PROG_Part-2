using System;
using System.Collections.Generic;
using System.IO;

namespace Ageis
{
    // Simple text-backed user favourite store. Stores lines in the form:
    // Name|FavouriteTopic
    internal static class UserDataStore
    {
        private static readonly string _dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "AEGIS");
        private static readonly string _file = Path.Combine(_dir, "users.txt");
        private static readonly object _lock = new();

        public static void AppendOrUpdateUserFavourite(string? name, string? favouriteTopic)
        {
            if (string.IsNullOrWhiteSpace(name)) return;
            var n = name!.Trim();
            var fav = favouriteTopic?.Trim() ?? string.Empty;

            lock (_lock)
            {
                try
                {
                    Directory.CreateDirectory(_dir);
                    var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    if (File.Exists(_file))
                    {
                        foreach (var line in File.ReadAllLines(_file))
                        {
                            if (string.IsNullOrWhiteSpace(line)) continue;
                            var parts = line.Split(new[] { '|' }, 2);
                            var key = parts[0].Trim();
                            var val = parts.Length > 1 ? parts[1].Trim() : string.Empty;
                            if (!dict.ContainsKey(key)) dict[key] = val;
                        }
                    }

                    dict[n] = fav; // add or update

                    using var writer = new StreamWriter(_file, false);
                    foreach (var kvp in dict)
                    {
                        writer.WriteLine($"{kvp.Key}|{kvp.Value}");
                    }
                }
                catch
                {
                    // ignore errors writing user file
                }
            }
        }

        public static Dictionary<string, string> ReadAll()
        {
            var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            lock (_lock)
            {
                try
                {
                    if (!File.Exists(_file)) return result;
                    foreach (var line in File.ReadAllLines(_file))
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;
                        var parts = line.Split(new[] { '|' }, 2);
                        var key = parts[0].Trim();
                        var val = parts.Length > 1 ? parts[1].Trim() : string.Empty;
                        if (!result.ContainsKey(key)) result[key] = val;
                    }
                }
                catch
                {
                    // ignore read errors
                }
            }

            return result;
        }
    }
}
