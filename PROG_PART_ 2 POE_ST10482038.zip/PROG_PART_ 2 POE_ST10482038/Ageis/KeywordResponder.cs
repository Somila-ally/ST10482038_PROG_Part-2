using System;
using System.Collections.Generic;

namespace Ageis
{
    internal class KeywordResponder
    {
        private readonly Dictionary<string, List<string>> _responses = new(StringComparer.OrdinalIgnoreCase);
        private readonly Random _random = new();

        public KeywordResponder()
        {
            // Populate with cybersecurity-related keywords and multiple responses
            _responses["password"] = new List<string>
            {
                "Use a strong unique password and consider a reputable password manager.",
                "Prefer long passphrases and avoid reusing passwords across sites.",
                "Combine length and unpredictability; enable 2FA wherever possible.",
                "Tip: use a passphrase with four or more unrelated words for memorability and strength."
            };

            _responses["phishing"] = new List<string>
            {
                "Phishing often uses urgent language — don't click links or provide credentials.",
                "Verify the sender address and hover links to check destination before clicking.",
                "When in doubt, contact the organisation through an independent channel.",
                "If you received a suspicious attachment, scan it with antivirus before opening."
            };

            _responses["privacy"] = new List<string>
            {
                "Review app permissions and limit access to sensitive data.",
                "Use privacy settings in services and consider removing unused apps.",
                "Be cautious sharing personal details on social platforms.",
                "Consider using tracker-blocking browser extensions and privacy-respecting search engines."
            };

            _responses["scam"] = new List<string>
            {
                "Common scams ask for money or personal data urgently — pause and verify.",
                "Never send funds or personal documents to unknown requesters.",
                "Report suspected scams to the relevant platform or your bank.",
                "Ask for official contact details and verify via a different channel before responding."
            };

            _responses["malware"] = new List<string>
            {
                "Keep your OS and apps updated and avoid installing software from unknown sources.",
                "Use reputable anti-malware tools and scan suspicious files.",
                "If infected, isolate the device and follow incident response guidance."
            };

            _responses["vpn"] = new List<string>
            {
                "A trusted VPN encrypts traffic on public Wi‑Fi and reduces eavesdropping risk.",
                "Choose a VPN provider with a strong privacy policy and good reputation.",
                "Remember a VPN doesn't replace good endpoint security and updates."
            };

            _responses["2fa"] = new List<string>
            {
                "Enable two-factor authentication for important accounts to block many attacks.",
                "Use an authenticator app or hardware key rather than SMS if possible.",
                "2FA greatly reduces the chance of unauthorised access even if passwords leak."
            };
        }

        public string? GetResponse(string input, out string matchedKey)
        {
            matchedKey = string.Empty;
            if (string.IsNullOrWhiteSpace(input)) return null;

            var lower = input.ToLowerInvariant();
            foreach (var key in _responses.Keys)
            {
                if (lower.Contains(key, StringComparison.OrdinalIgnoreCase))
                {
                    var list = _responses[key];
                    var choice = list[_random.Next(list.Count)];
                    matchedKey = key;
                    return choice;
                }
            }

            return null;
        }

        public List<string> GetAllKeywords() => new List<string>(_responses.Keys);
    }
}
