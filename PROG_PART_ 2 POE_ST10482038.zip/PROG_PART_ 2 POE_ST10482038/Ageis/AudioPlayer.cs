using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace Ageis
{
    // Simple AudioPlayer that uses Windows SAPI.SpVoice for TTS when available.
    // Falls back to a no-op if SAPI is unavailable. Methods are resilient and
    // should not throw to avoid crashing the UI.
    internal static class AudioPlayer
    {
        private static dynamic? _sapiVoice;
        private static bool _initialized = false;
        private static readonly Random _rng = new();
        private static readonly string[] _friendlyPrefixes = new[]
        {
            "Hi there!",
            "Hello!",
            "Hey there!",
            "Welcome to Aegis Cyber Sentinel — your Cyber Security Assistant.",
            "Nice to meet you!"
        };

        // Try to initialize SAPI COM object once. Silent failure if not available.
        private static void EnsureInitialized()
        {
            if (_initialized) return;
            _initialized = true;
            try
            {
                // Use late-bound COM activation to avoid a hard reference
                // to Microsoft Speech assemblies. This works on Windows with SAPI.
                var type = Type.GetTypeFromProgID("SAPI.SpVoice");
                if (type != null)
                {
                    _sapiVoice = Activator.CreateInstance(type);
                }
            }
            catch
            {
                _sapiVoice = null;
            }
        }

        public static void EnsureGreetingAudioExists()
        {
            // Nothing to create on disk; initialization is enough.
            try { EnsureInitialized(); } catch { }
        }

        public static void PlayGreetingIfExists()
        {
            // If SAPI available, speak a short welcome asynchronously.
            try
            {
                EnsureInitialized();
                if (_sapiVoice != null)
                {
                    // speak the project-specific welcome phrase on a background thread
                    ThreadPool.QueueUserWorkItem(_ =>
                    {
                        try { _sapiVoice.Speak("Welcome to Aegis Cyber Sentinel am a Cyber Security Assistant.", 1); }
                        catch { }
                    });
                }
            }
            catch { }
        }

        public static void SpeakText(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return;
            try
            {
                EnsureInitialized();
                if (_sapiVoice != null)
                {
                    // Use synchronous speak on background thread caller must ensure not to block UI
                    _sapiVoice.Speak(text, 1);
                }
            }
            catch
            {
                // Swallow exceptions — audio is non-essential
            }
        }
    }
}
